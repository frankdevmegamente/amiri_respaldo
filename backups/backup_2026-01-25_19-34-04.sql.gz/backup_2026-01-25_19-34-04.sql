-- Backup de base de datos: guiaspar_amiri_db
-- Fecha: 2026-01-25 19:34:04

SET FOREIGN_KEY_CHECKS=0;

-- Tabla: auditoria
DROP TABLE IF EXISTS `auditoria`;
CREATE TABLE `auditoria` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `usuario_id` int NOT NULL COMMENT 'Quién hizo la acción',
  `accion` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'INSERT, UPDATE, DELETE, LOGIN, LOGOUT, etc.',
  `modulo` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'clientes, gastos, usuarios, prestamos, etc.',
  `tabla` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Tabla afectada',
  `registro_id` int DEFAULT NULL COMMENT 'ID del registro afectado',
  `datos_anteriores` json DEFAULT NULL COMMENT 'Valores antes del cambio',
  `datos_nuevos` json DEFAULT NULL COMMENT 'Valores después del cambio',
  `descripcion` text COLLATE utf8mb4_general_ci COMMENT 'Descripción legible de la acción',
  `ip_address` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'IP desde donde se hizo',
  `user_agent` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'Navegador/dispositivo',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_accion` (`accion`),
  KEY `idx_modulo` (`modulo`),
  KEY `idx_tabla_registro` (`tabla`,`registro_id`),
  KEY `idx_fecha` (`created_at`),
  KEY `idx_modulo_accion` (`modulo`,`accion`),
  KEY `idx_usuario_fecha` (`usuario_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `auditoria` VALUES ('1', '1', 'UPDATE', 'usuarios', 'usuarios', '1', '{\"id\": 1, \"rol\": \"admin\", \"email\": \"admin@amiri.com\", \"activo\": 1, \"nombre\": \"Admin Amiri\", \"password\": \"$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi\", \"creado_en\": \"2025-10-29 15:18:03\", \"reset_token\": null, \"reset_expires_at\": null}', '{\"rol\": \"admin\", \"email\": \"admin@amiri.com\", \"nombre\": \"Admin Amiriii\"}', 'Actualizó usuario: Admin Amiriii', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-01-25 17:29:39');
INSERT INTO `auditoria` VALUES ('2', '1', 'LOGIN', 'auth', 'usuarios', '1', NULL, NULL, 'Usuario \'Admin Amiriii\' inició sesión', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', '2026-01-25 18:34:39');

-- Tabla: clientes
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `promotor_id` int NOT NULL,
  `retencion_total` decimal(5,2) DEFAULT NULL,
  `porcentaje_amiri` decimal(5,2) DEFAULT NULL,
  `porcentaje_promotor` decimal(5,2) DEFAULT NULL,
  `contacto` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cuenta_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cliente_promotor` (`promotor_id`),
  KEY `fk_cliente_cuenta` (`cuenta_id`),
  KEY `idx_promotor` (`promotor_id`),
  KEY `idx_cuenta_cliente` (`cuenta_id`),
  CONSTRAINT `fk_cliente_cuenta` FOREIGN KEY (`cuenta_id`) REFERENCES `cuentas` (`id`),
  CONSTRAINT `fk_cliente_promotor` FOREIGN KEY (`promotor_id`) REFERENCES `promotores` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `clientes` VALUES ('4', 'toño hdez', '7', '1.00', '0.80', '0.20', '3382829494', '18');

-- Tabla: cuentas
DROP TABLE IF EXISTS `cuentas`;
CREATE TABLE `cuentas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `numero_cuenta` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `banco` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `saldo_actual` decimal(12,2) NOT NULL DEFAULT '0.00',
  `tipo_cuenta` int NOT NULL DEFAULT '1',
  `es_caja_empresa` tinyint(1) DEFAULT '0',
  `tipo_moneda` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'MXN',
  `documento_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `fk_tipo_cuenta` (`tipo_cuenta`),
  KEY `idx_activo_tipo` (`activo`,`tipo_cuenta`),
  KEY `idx_tipo_moneda` (`tipo_moneda`),
  KEY `idx_tipo_activo` (`tipo_cuenta`,`activo`),
  KEY `idx_moneda` (`tipo_moneda`),
  KEY `idx_tipo_activo_moneda` (`tipo_cuenta`,`activo`,`tipo_moneda`),
  CONSTRAINT `fk_tipo_cuenta` FOREIGN KEY (`tipo_cuenta`) REFERENCES `cuentas_tipo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cuentas` VALUES ('1', 'Comisiones AMIRI', NULL, NULL, '1', '2026-01-16 12:07:00', '800.00', '3', '0', 'MXN', NULL);
INSERT INTO `cuentas` VALUES ('7', 'Caja de Efectivo', NULL, NULL, '1', '2026-01-16 19:50:42', '101000.00', '2', '1', 'MXN', NULL);
INSERT INTO `cuentas` VALUES ('14', 'Tarpen SA', '1029384756102938475', 'BANREGIO', '1', '2026-01-19 13:36:05', '99800.00', '1', '0', 'MXN', 'uploads/cuentas/cuenta_1768851365_696e87a55f683.png');
INSERT INTO `cuentas` VALUES ('17', 'Comisiones - Kike Rizo', NULL, NULL, '1', '2026-01-22 13:04:18', '0.00', '5', '0', 'MXN', NULL);
INSERT INTO `cuentas` VALUES ('18', 'Caja Cliente - toño hdez', NULL, NULL, '1', '2026-01-22 13:04:46', '0.00', '4', '0', 'MXN', NULL);

-- Tabla: cuentas_tipo
DROP TABLE IF EXISTS `cuentas_tipo`;
CREATE TABLE `cuentas_tipo` (
  `id` int NOT NULL,
  `descripcion` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `descripcion` (`descripcion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cuentas_tipo` VALUES ('1', 'Bancaria');
INSERT INTO `cuentas_tipo` VALUES ('2', 'Caja');
INSERT INTO `cuentas_tipo` VALUES ('3', 'Capital');
INSERT INTO `cuentas_tipo` VALUES ('4', 'Cliente');
INSERT INTO `cuentas_tipo` VALUES ('5', 'Promotor');
INSERT INTO `cuentas_tipo` VALUES ('6', 'Proveedor');

-- Tabla: flujo_movimientos
DROP TABLE IF EXISTS `flujo_movimientos`;
CREATE TABLE `flujo_movimientos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `grupo_id` bigint DEFAULT NULL,
  `fecha` date NOT NULL,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `servicio_id` int NOT NULL,
  `tipo` enum('entrada','salida','traspaso','comision','ajuste') COLLATE utf8mb4_general_ci NOT NULL,
  `moneda` enum('MXN','USD','USDT') COLLATE utf8mb4_general_ci NOT NULL,
  `monto` decimal(18,6) NOT NULL,
  `cuenta_origen_id` int DEFAULT NULL,
  `cuenta_destino_id` int DEFAULT NULL,
  `cliente_id` int DEFAULT NULL,
  `promotor_id` int DEFAULT NULL,
  `proveedor_id` int DEFAULT NULL,
  `referencia_id` bigint DEFAULT NULL,
  `referencia_tipo` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `paridad` decimal(18,6) DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `activo` tinyint DEFAULT '1',
  `usuario_id` int DEFAULT NULL COMMENT 'Usuario que registró el movimiento',
  `prestamista_id` int DEFAULT NULL COMMENT 'Si es pago/préstamo de prestamista',
  `gasto_id` int DEFAULT NULL COMMENT 'Si es un gasto registrado',
  PRIMARY KEY (`id`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_servicio` (`servicio_id`),
  KEY `idx_moneda` (`moneda`),
  KEY `idx_origen` (`cuenta_origen_id`),
  KEY `idx_destino` (`cuenta_destino_id`),
  KEY `idx_cliente` (`cliente_id`),
  KEY `idx_proveedor` (`proveedor_id`),
  KEY `idx_grupo_id` (`grupo_id`),
  KEY `idx_promotor_tipo` (`promotor_id`,`tipo`),
  KEY `idx_cuenta_destino` (`cuenta_destino_id`),
  KEY `idx_tipo_descripcion` (`tipo`,`descripcion`(20)),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_prestamista` (`prestamista_id`),
  KEY `idx_gasto` (`gasto_id`),
  KEY `idx_activo` (`activo`),
  KEY `idx_fecha_activo` (`fecha`,`activo`),
  KEY `idx_tipo_activo` (`tipo`,`activo`),
  CONSTRAINT `flujo_movimientos_ibfk_1` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `flujo_movimientos` VALUES ('1', '1769117265393', '2026-01-22', '2026-01-22 15:27:45', '1', 'entrada', 'MXN', '100000.000000', NULL, '14', '4', NULL, NULL, NULL, NULL, '1.000000', 'Venta de Efectivo - dinero recibido del cliente', '1', NULL, NULL, NULL);
INSERT INTO `flujo_movimientos` VALUES ('2', '1769117265393', '2026-01-22', '2026-01-22 15:27:45', '1', 'entrada', 'MXN', '99000.000000', NULL, '18', '4', NULL, NULL, NULL, NULL, '1.000000', 'Venta de Efectivo - efectivo recibido neto', '1', NULL, NULL, NULL);
INSERT INTO `flujo_movimientos` VALUES ('3', '1769117265393', '2026-01-22', '2026-01-22 15:27:45', '1', 'comision', 'MXN', '800.000000', NULL, '1', NULL, NULL, NULL, NULL, NULL, '1.000000', 'Comisión Amiri - Venta de Efectivo', '1', NULL, NULL, NULL);
INSERT INTO `flujo_movimientos` VALUES ('4', '1769117265393', '2026-01-22', '2026-01-22 15:27:45', '1', 'comision', 'MXN', '200.000000', NULL, '17', NULL, NULL, '7', NULL, NULL, '1.000000', 'Comisión Promotor - Venta de Efectivo', '1', NULL, NULL, NULL);
INSERT INTO `flujo_movimientos` VALUES ('5', '1769372236493', '2026-01-25', '2026-01-25 14:17:16', '1', 'salida', 'MXN', '100.000000', '14', NULL, NULL, '7', NULL, NULL, NULL, NULL, 'Pago de Comisiones a Kike Rizo', '1', NULL, NULL, NULL);
INSERT INTO `flujo_movimientos` VALUES ('6', '1769372259606', '2026-01-25', '2026-01-25 14:17:39', '1', 'salida', 'MXN', '100.000000', '14', NULL, NULL, '7', NULL, NULL, NULL, NULL, 'Pago de Comisiones a Kike Rizo', '1', NULL, NULL, NULL);

-- Tabla: gastos
DROP TABLE IF EXISTS `gastos`;
CREATE TABLE `gastos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `cuenta_id` int DEFAULT NULL,
  `flujo_id` bigint DEFAULT NULL,
  `tipo_gasto_id` int DEFAULT NULL,
  `monto` decimal(12,2) NOT NULL,
  `concepto` text COLLATE utf8mb4_general_ci,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_gastos_flujo` (`flujo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: inventario_divisas
DROP TABLE IF EXISTS `inventario_divisas`;
CREATE TABLE `inventario_divisas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `moneda` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `cantidad_original` decimal(20,8) NOT NULL,
  `cantidad_restante` decimal(20,8) NOT NULL,
  `paridad` decimal(18,8) NOT NULL,
  `cuenta_id` int NOT NULL,
  `flujo_id` bigint NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flujo_id` (`flujo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: movimientos_cuenta
DROP TABLE IF EXISTS `movimientos_cuenta`;
CREATE TABLE `movimientos_cuenta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cuenta_id` int NOT NULL,
  `flujo_id` bigint NOT NULL,
  `tipo` enum('entrada','salida') COLLATE utf8mb4_general_ci NOT NULL,
  `monto` decimal(14,2) NOT NULL,
  `saldo_anterior` decimal(14,2) NOT NULL,
  `saldo_nuevo` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: pagos_comisiones_promotores
DROP TABLE IF EXISTS `pagos_comisiones_promotores`;
CREATE TABLE `pagos_comisiones_promotores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `promotor_id` int NOT NULL,
  `cuenta_pago_id` int NOT NULL COMMENT 'Cuenta desde donde se pagó (caja/banco empresa)',
  `cuenta_promotor_id` int NOT NULL COMMENT 'Cuenta del promotor donde se registra',
  `monto_pagado` decimal(12,2) NOT NULL,
  `fecha_pago` date NOT NULL,
  `flujo_id` bigint DEFAULT NULL COMMENT 'Referencia al flujo_movimientos',
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_promotor` (`promotor_id`),
  KEY `idx_cuenta_pago` (`cuenta_pago_id`),
  KEY `idx_cuenta_promotor` (`cuenta_promotor_id`),
  KEY `idx_flujo` (`flujo_id`),
  KEY `idx_fecha` (`fecha_pago`),
  KEY `idx_promotor_fecha` (`promotor_id`,`fecha_pago`),
  KEY `idx_activo` (`activo`),
  CONSTRAINT `fk_pago_cuenta_pago` FOREIGN KEY (`cuenta_pago_id`) REFERENCES `cuentas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pago_cuenta_promotor` FOREIGN KEY (`cuenta_promotor_id`) REFERENCES `cuentas` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_pago_flujo` FOREIGN KEY (`flujo_id`) REFERENCES `flujo_movimientos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pago_promotor` FOREIGN KEY (`promotor_id`) REFERENCES `promotores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `pagos_comisiones_promotores` VALUES ('1', '7', '14', '17', '100.00', '2026-01-25', '5', 'Pago de comisiones pendientes', '2026-01-25 14:17:16', '1');
INSERT INTO `pagos_comisiones_promotores` VALUES ('2', '7', '14', '17', '100.00', '2026-01-25', '6', 'Pago de comisiones pendientes', '2026-01-25 14:17:39', '1');

-- Tabla: prestamistas
DROP TABLE IF EXISTS `prestamistas`;
CREATE TABLE `prestamistas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_general_ci,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `prestamistas` VALUES ('1', 'Diego', '01928374', 'diego@gmail.com', 'Av Patria', '1', '2026-01-22 16:25:16');

-- Tabla: prestamos_prestamistas
DROP TABLE IF EXISTS `prestamos_prestamistas`;
CREATE TABLE `prestamos_prestamistas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `prestamista_id` int NOT NULL,
  `cuenta_id` int DEFAULT NULL,
  `monto` decimal(12,2) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` text COLLATE utf8mb4_general_ci,
  `estado` enum('pendiente','pagado','parcial') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pendiente',
  `monto_pagado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fecha_pago` date DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_prestamo_prestamista` (`prestamista_id`),
  KEY `idx_prestamista` (`prestamista_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_estado_activo` (`estado`,`activo`),
  KEY `idx_prestamista_estado` (`prestamista_id`,`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `prestamos_prestamistas` VALUES ('1', '1', '7', '200000.00', '2026-01-22', 'Test', 'pendiente', '0.00', NULL, '2026-01-22 16:26:13', '2026-01-22 16:26:13', '1');

-- Tabla: promotores
DROP TABLE IF EXISTS `promotores`;
CREATE TABLE `promotores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cuenta_id` int DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  KEY `fk_promotor_cuenta` (`cuenta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `promotores` VALUES ('7', 'Kike Rizo', '3382828282', 'asf12@gmail.com', '17', '1', '2026-01-22 13:04:18');

-- Tabla: proveedores
DROP TABLE IF EXISTS `proveedores`;
CREATE TABLE `proveedores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `telefono` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cuenta_id` int DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_proveedor_cuenta` (`cuenta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: servicios
DROP TABLE IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_general_ci,
  `tipo_movimiento` enum('entrada','salida') COLLATE utf8mb4_general_ci NOT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `servicios` VALUES ('1', 'Venta de Efectivo', 'Venta de efectivo a clientes', 'entrada', '1', '2025-11-12 15:02:41', '2025-11-12 15:02:41');
INSERT INTO `servicios` VALUES ('2', 'Venta de Dolares', 'Venta de dólares a clientes', 'entrada', '1', '2025-11-12 15:02:41', '2025-11-12 15:02:41');
INSERT INTO `servicios` VALUES ('3', 'Venta de USDT', 'Venta de USDT a clientes', 'entrada', '1', '2025-11-12 15:02:41', '2025-11-12 15:02:41');
INSERT INTO `servicios` VALUES ('4', 'Cambio de Flujo', 'Movimientos entre cuentas sin cambiar capital', 'salida', '1', '2025-11-12 15:02:41', '2025-11-12 15:02:41');
INSERT INTO `servicios` VALUES ('5', 'Compra de Dolares', 'Compra de dólares a clientes', 'salida', '1', '2025-11-12 15:02:41', '2025-11-12 15:02:41');
INSERT INTO `servicios` VALUES ('6', 'Compra de USDT', 'Compra de USDT a clientes', 'salida', '1', '2025-11-12 15:02:41', '2026-01-15 22:44:26');

-- Tabla: tipos_gasto
DROP TABLE IF EXISTS `tipos_gasto`;
CREATE TABLE `tipos_gasto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: usuarios
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `rol` enum('admin','prestamista','usuario') COLLATE utf8mb4_general_ci DEFAULT 'usuario',
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reset_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reset_expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usuarios` VALUES ('1', 'Admin Amiriii', 'admin@amiri.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '1', '2025-10-29 15:18:03', NULL, NULL);

-- Tabla: ventas_efectivo_clientes
DROP TABLE IF EXISTS `ventas_efectivo_clientes`;
CREATE TABLE `ventas_efectivo_clientes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cliente_id` int NOT NULL,
  `cuenta_cliente_id` int DEFAULT NULL COMMENT 'Caja del cliente',
  `flujo_venta_id` bigint DEFAULT NULL COMMENT 'Referencia al grupo de movimientos de la venta',
  `flujo_pago_id` bigint DEFAULT NULL COMMENT 'Referencia al grupo de movimientos del pago',
  `monto_total` decimal(12,2) NOT NULL COMMENT 'Monto total de la venta',
  `comision_amiri` decimal(12,2) NOT NULL DEFAULT '0.00',
  `comision_promotor` decimal(12,2) NOT NULL DEFAULT '0.00',
  `monto_neto_cliente` decimal(12,2) NOT NULL COMMENT 'Lo que recibe el cliente después de comisiones',
  `fecha` date NOT NULL,
  `descripcion` text COLLATE utf8mb4_general_ci,
  `estado` enum('pendiente','pagado','parcial') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pendiente',
  `monto_pagado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fecha_pago` date DEFAULT NULL,
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `actualizado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `activo` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_cliente` (`cliente_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`),
  KEY `idx_flujo_venta` (`flujo_venta_id`),
  KEY `idx_flujo_pago` (`flujo_pago_id`),
  KEY `idx_estado_activo` (`estado`,`activo`),
  KEY `idx_cliente_estado` (`cliente_id`,`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Registro de ventas de efectivo pendientes de pago por clientes';

INSERT INTO `ventas_efectivo_clientes` VALUES ('1', '4', '18', '1769117265393', NULL, '100000.00', '800.00', '200.00', '99000.00', '2026-01-22', 'Venta de efectivo - Pendiente de pago', 'pagado', '99000.00', '2026-01-22', '2026-01-22 15:27:45', '2026-01-22 16:27:27', '1');

SET FOREIGN_KEY_CHECKS=1;
